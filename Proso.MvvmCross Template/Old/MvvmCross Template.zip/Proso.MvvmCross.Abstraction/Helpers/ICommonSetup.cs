﻿namespace $safeprojectname$.Helpers
{
    public interface ICommonSetup
    {
        void InitializeViewLookup();
    }
}